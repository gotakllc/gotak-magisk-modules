#!/system/bin/sh

keepalive=yes

if [ "$keepalive" = "yes" ]
then
  echo "Startup enabled"
  /system/bin/keepalive.sh &
else
  echo "startup function disabled"
fi
