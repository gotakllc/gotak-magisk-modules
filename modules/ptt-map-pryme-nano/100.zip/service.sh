#!/system/bin/sh

# Example content of service.sh
pryme_nano=yes

echo "Starting PTT script..." > /data/local/tmp/service.log

while true; do
    if [ "$pryme_nano" = "yes" ]; then
        echo "ptt nano function enabled" >> /data/local/tmp/service.log
        /system/bin/pryme_nano.sh >> /data/local/tmp/service.log 2>&1
    else
        echo "commercial function disabled" >> /data/local/tmp/service.log
        exit 0
    fi

    # If the script crashes, wait for a bit before restarting
    sleep 1

done
echo "Service script started" > /data/local/tmp/service.log

