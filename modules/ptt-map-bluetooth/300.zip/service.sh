#!/system/bin/sh

#PTT is mapped in latest firmware already
PTT=yes
retevis=yes
italkie=no

if [ "$PTT" = "yes" ]
then
  echo "PTT function enabled"
  /system/bin/ptt_down.sh &
  /system/bin/ptt_up.sh &
else
  echo "PTT function disabled"
fi

if [ "$retevis" = "yes" ]
then
  echo "retevis function enabled"
  /system/bin/retevis_down.sh &
  /system/bin/retevis_up.sh &
else
  echo "retevis function disabled"
fi

if [ "$italkie" = "yes" ]
then
  echo "italkie function enabled"
  /system/bin/italkie_down.sh &
  /system/bin/italkie_up.sh &
else
  echo "italkie function disabled"
fi
