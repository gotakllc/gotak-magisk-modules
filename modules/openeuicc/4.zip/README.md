Magisk module to add OpenEUICC.  
OpenEUICC is a tool for managing eSIM profiles.

OpenEUICC is licensed under GPL v2.  
https://gitea.angry.im/PeterCxy/OpenEUICC