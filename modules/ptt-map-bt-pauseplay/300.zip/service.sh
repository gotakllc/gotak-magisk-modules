#!/system/bin/sh

# Example content of service.sh
btpp=yes

echo "Starting PTT script..." > /data/local/tmp/service.log

while true; do
    if [ "$btpp" = "yes" ]; then
        echo "btpp ptt function enabled" >> /data/local/tmp/service.log
        /system/bin/btpp.sh >> /data/local/tmp/service.log 2>&1
    else
        echo "btpp function disabled" >> /data/local/tmp/service.log
        exit 0
    fi

    # If the script crashes, wait for a bit before restarting
    sleep 1

done
echo "BT Service script started" > /data/local/tmp/service.log

