#!/system/bin/sh

keepalive=yes

if [ "$keepalive" = "yes" ]
then
  echo "Startup enabled"
  /system/bin/kiwix_exfat_watchdog.sh &
else
  echo "startup function disabled"
fi
