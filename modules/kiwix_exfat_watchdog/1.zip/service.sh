#!/system/bin/sh

# Path for blkid and mount points
WATCHDOG_INTERVAL=10 # Check every 10 seconds
MOUNT_POINT_BASE="/mnt/media_rw"
UUID_PATH="/storage/sdcard0/Android"
MEDIA_PATH="$UUID_PATH/media/org.kiwix.kiwixmobile"
DATA_PATH="$UUID_PATH/data/org.kiwix.kiwixmobile"
EXFAT_MOUNT="/mnt/exfat"

# Function to mount and bind exFAT SD card
mount_and_bind_sdcard() {
    DEV_PATH=$1
    UUID=$2

    MOUNT_POINT="$MOUNT_POINT_BASE/$UUID"
    mkdir "$MOUNT_POINT_BASE/$UUID"

    # Mount the exFAT card
    if mount.exfat -o rw,uid=1000,gid=1015 $DEV_PATH $MOUNT_POINT; then
        echo "Mounted $DEV_PATH at $MOUNT_POINT"
        # Bind mount to the appropriate path based on block name
        if echo "$DEV_PATH" | grep -q "mmcblk"; then
            
            mount --bind $MOUNT_POINT $MEDIA_PATH
            echo "Bind mounted to $MEDIA_PATH"
        else
            mount --bind $MOUNT_POINT $DATA_PATH
            echo "Bind mounted to $DATA_PATH"
        fi
    else
        echo "Failed to mount $DEV_PATH"
    fi
}

# Function to unmount and clean up
unmount_and_cleanup() {
    DEV_PATH=$1
    UUID=$2

    MOUNT_POINT="$MOUNT_POINT_BASE/$UUID"

    # Unmount bind mounts
    if mountpoint -q $MEDIA_PATH; then
        umount $MEDIA_PATH
        echo "Unmounted $MEDIA_PATH"
    fi

    if mountpoint -q $DATA_PATH; then
        umount $DATA_PATH
        echo "Unmounted $DATA_PATH"
    fi

    # Unmount exFAT mount point
    if mountpoint -q $MOUNT_POINT; then
        umount $MOUNT_POINT
        echo "Unmounted $MOUNT_POINT"
    fi
}

# Watchdog loop
while true; do
    # Check for exFAT partitions using blkid
    for DEV_PATH in $(blkid | grep exfat | cut -d: -f1); do
        # Get the UUID of the partition
        UUID=$(blkid -s UUID -o value $DEV_PATH)
        MOUNT_POINT="$MOUNT_POINT_BASE/$UUID"

        if ! mountpoint -q $MOUNT_POINT; then
            # Mount and bind if not already mounted
            mount_and_bind_sdcard $DEV_PATH $UUID
        fi
    done

    # Clean up unmounted exFAT partitions
    for MOUNT_POINT in $(ls $MOUNT_POINT_BASE); do
        if ! blkid | grep -q $MOUNT_POINT; then
            # If the mount point is no longer present, unmount and clean up
            unmount_and_cleanup $DEV_PATH $MOUNT_POINT
        fi
    done

    # Wait before checking again
    sleep $WATCHDOG_INTERVAL
done
