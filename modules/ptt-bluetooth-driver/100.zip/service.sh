#!/system/bin/sh

startup=yes

if [ "$startup" = "yes" ]
then
  echo "Startup enabled"
  /system/bin/startup.sh
else
  echo "Startup disabled"
fi
