#!/system/bin/sh

PTT=yes
italkie=yes
silynx=yes

if [ "$PTT" = "yes" ]
then
  echo "PTT function enabled"
  /system/bin/ptt_down.sh &
  /system/bin/ptt_up.sh &
else
  echo "PTT function disabled"
fi

if [ "$italkie" = "yes" ]
then
  echo "italkie function enabled"
  /system/bin/italkie_down.sh &
  /system/bin/italkie_up.sh &
else
  echo "italkie function disabled"
fi

if [ "$silynx" = "yes" ]
then
  echo "silynx function enabled"
  /system/bin/silynx_down.sh &
  /system/bin/silynx_up.sh &
else
  echo "silynx function disabled"
fi
