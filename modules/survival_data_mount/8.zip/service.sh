#!/system/bin/sh

# Copy file to storage after every boot
mkdir /storage/emulated/0/scripts
cp /data/adb/modules/survival_data_mount/*.txt /storage/emulated/0/scripts/

